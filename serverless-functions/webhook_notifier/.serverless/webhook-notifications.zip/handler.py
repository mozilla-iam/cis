
def handle(event, context):
    pass